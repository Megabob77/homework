package homework1.task3;

public class Book {
    public static void main(String[] args) {

    }
}
