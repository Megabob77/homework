package homework1.task3;

public class Title {
}
