package homework1.task4;

public class Computer {
}
