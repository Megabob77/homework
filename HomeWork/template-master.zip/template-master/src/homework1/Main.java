package homework1;

import homework1.add_task.Address;
import homework1.task2.Rectangle;
import homework1.task4.Computer;

public class Main {
    public static void main(String[] args) {
        /*----------ADDITIONAL TASK---------*/
        Address address = new Address();

        /*----------TASK 2---------*/
        Rectangle rectangle = new Rectangle();

        /*----------TASK 3---------*/
        Computer computer = new Computer();
    }
}
