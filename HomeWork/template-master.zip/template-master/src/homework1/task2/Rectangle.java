package homework1.task2;

public class Rectangle {
}
