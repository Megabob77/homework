package homework3.add_task;

public class Printer {
}
