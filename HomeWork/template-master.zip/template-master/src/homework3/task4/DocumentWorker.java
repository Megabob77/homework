package homework3.task4;

public class DocumentWorker {
}
