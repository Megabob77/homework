package homework3;

import homework3.add_task.Printer;
import homework3.task2.ClassRoom;

public class Main {
    public static void main(String[] args) {
        Main main = new Main();

        main.startTask2();
        main.startTask3();
        main.startTask4();
        main.startAddTask();
    }

    void startTask2() {
        Printer printer = new Printer();
    }

    void startTask3() {
        ClassRoom room = new ClassRoom();
    }

    void startTask4() {

    }

    void startAddTask() {
    }
}
