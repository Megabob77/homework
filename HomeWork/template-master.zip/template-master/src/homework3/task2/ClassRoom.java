package homework3.task2;

public class ClassRoom {
}
