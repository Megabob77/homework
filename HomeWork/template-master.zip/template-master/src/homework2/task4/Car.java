package homework2.task4;

public class Car {
}
