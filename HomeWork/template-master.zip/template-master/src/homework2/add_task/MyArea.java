package homework2.add_task;

public class MyArea {
}
