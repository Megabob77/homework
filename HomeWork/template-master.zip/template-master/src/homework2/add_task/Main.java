package homework2.add_task;

public class Main {
    public static void main(String[] args) {

    }
}