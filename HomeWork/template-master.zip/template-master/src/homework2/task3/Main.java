package homework2.task3;

public class Main {
    public static void main(String[] args) {

    }
}
