package homework2.task3;

public class Car {
}
